<div id="side-nav">
	<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar() ) : ?>
	 <h2>About</h2>
	 <p>This is the default sidebar, add some widgets to change it.</p>
	<?php endif; ?>
</div>
