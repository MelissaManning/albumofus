<?php get_header(); ?>

<div id="404">
	<h1>404!</h1>
	<h3>
		Oh god, what have you done?!?!?
	</h3>
	<p>
		Not sure what you were looking for, but feel free to <a href="/" title="Bri Manning">head on home</a>, or find out more <a href="/about" title="About Bri Manning">about me</a>. That last part was to give myself an ego boost.
	</p>
</div>

<?php get_footer(); ?>